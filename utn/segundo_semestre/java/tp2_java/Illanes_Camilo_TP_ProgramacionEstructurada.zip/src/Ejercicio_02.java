import java.util.Scanner;

public class Ejercicio_02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        int num1 = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese el segundo número: ");
        int num2 = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese el tercer número: ");
        int num3 = Integer.parseInt(sc.nextLine());

        int mayor = num1;

        if (num2 > mayor){
            mayor = num2;
        }

        if (num3 > mayor){
            mayor = num3;
        }

        System.out.println("El mayor es: "+mayor);

        sc.close();
    }
}